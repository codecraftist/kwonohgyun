// 이메일 인증
$('#btn-email-confirm').click(function timer(){
    console.log('이메일인증');
    $('#timer').removeClass('hidden');
    var timer = 0;
    var min = 0;
    var sec = 0;
    
    if (timer == 0) {
        timer = setInterval(() => {
            sec--;
            if(sec == 00){
                min--; sec = 59;
            }
            
            // timer();

        }, 1000);
        
    }
});


// 아이디칸
$('#input-user-account').click(function (){   
});


// 비밀번호칸
$('#input-user-password').click(function (){  
});


// 회원가입 버튼

$('#btn-join').click(function (){

    var uid = $('#input-user-account').val();
    var pwd = $('#input-user-password').val();
    var pwd = $('#input-user-email').val();

    function inspect(userdata) {
        

        for(var i; i < userdata.length; i++){

            if(userdata.length >= 13 && userdata.length <= 5){
                alert('아이디 글자수 제한')
                return;
            } 

            var pattern = /^0-9/;
            if(userdata[0] == pattern) {
                alert('아이디 형식 제한');
                return;
            }
            var pattern2 = /^[0-9a-z]/i;
            if(userdata[i] !== pattern2){
                alert('아이디 형식 제한');
                return;
            } 


        }

    }
    

    

    console.log(joinID);
    console.log(joinPWD);

    //데이터검증
    //패스워드 2개일치
    // 실패메세지
    // 아이디 6글자 최대 , 영문자, 숫자만 가능 , 숫자시작 불가
    // 패스워드 : 숫자 영문자 특수문자 1개씩 포함 길이는 6글자 12글자
    inspect(uid);
    inspect(pwd)

    $.ajax({
        url : '/signup',
        method: 'post',
        data : {
            uid : uid,
            pwd : pwd,
            email : email
        }
    }).done(function (data) {
        if(data.sucess) {
            location.href = '/login-ok';
        } else {
            $('#msg-alert').text(data.msg);
        }
    })


});